import React from "react";

const NotFound = () => {
  return (
    <div className="center-item">
      <h3>Page does not exist</h3>
    </div>
  );
};
export default NotFound;
